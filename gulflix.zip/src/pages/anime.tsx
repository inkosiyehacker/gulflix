import CategorywisePage from "@/components/CategorywisePage";

const Anime = () => {
  return <CategorywisePage categoryDiv="tv" categoryPage="anime" />;
};

export default Anime;
