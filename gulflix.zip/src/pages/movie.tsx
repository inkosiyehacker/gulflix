import CategorywisePage from "@/components/CategorywisePage";
const Movie = () => {
  return <CategorywisePage categoryDiv="movie" />;
};

export default Movie;
